const calculateSquare = (number) => {
    return number * number;
  };
  
  console.log(calculateSquare(5));
  console.log(calculateSquare(8));