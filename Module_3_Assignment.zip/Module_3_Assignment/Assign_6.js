class MathUtility {
    static multiply(a, b) {
      return a * b;
    }
  }
  
  console.log(MathUtility.multiply(5, 3));
  console.log(MathUtility.multiply(2, 8));