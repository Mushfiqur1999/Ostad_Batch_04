function printObjectProperties(obj) {
  if (Object.keys(obj).length === 0) {
    console.log("Object is empty");
    return;
  }

  for (let prop in obj) {
    console.log(`${prop}: ${obj[prop]}`);
  }
}

const person = {
  name: "Mushfiqur Rahman",
  age: 22,
  city: "Dhaka"
};

const emptyObj = {};

printObjectProperties(person);
printObjectProperties(emptyObj);
