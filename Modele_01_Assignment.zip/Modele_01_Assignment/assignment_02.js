// (2) Topic: Filter Even Numbers

var arr1 = [12, 34, 45, 23, 6, 78, 54, 90];

var evens = arr1.filter(x => x % 2 === 0);

document.write(`Filtered Even Numbers : [ ${evens} ]` );