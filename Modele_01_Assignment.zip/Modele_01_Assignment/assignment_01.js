//(1) Topic: Online Store Discount Calculator (If-Else Statement)


var amount = prompt("Your Purchase amount : ")

if(amount>0 && amount<50){

    document.write(`Your Purchase amount : ${amount}, <br><b>You have no discount !</b></br> `)
}

else if(amount>=50 && amount<100){

    var discount = ((5*amount)/100);
    var disAmount = (amount - discount)

    document.write(`Your Purchase amount : ${amount}, <br><b>You have get 5% discount bonus !.<br>Your Discount Amount is : ${discount},<br> Total Amount after discount ${disAmount}</b></br> `)
}

else if(amount>=100 && amount<200){

    var discount = ((10*amount)/100);
    var disAmount = (amount - discount)

    document.write(`Your Purchase amount : ${amount}, <br><b>You have get 10% discount bonus !.<br>Your Discount Amount is : ${discount},<br> Total Amount after discount ${disAmount}</b></br> `)
}

else if(amount>=200){

    var discount = ((15*amount)/100);
    var disAmount = (amount - discount)

    document.write(`Your Purchase amount : ${amount}, <br><b>You have get 15% discount bonus !.<br>Your Discount Amount is : ${discount},<br> Total Amount after discount ${disAmount}</b></br> `)

}

else{
    document.write("Invalid Amount")
}

