//(4) Topic: Grade Calculator (JavaScript Switch Case)

var result = parseInt(prompt("Enter Your number : "));
switch(true){
    case(result<=100 && result>=90):
        document.write("Your restlt is : A")
       break;
    
    case(result<90 && result>=80):
        document.write("Your restlt is : B");
        break;

     case(result<80 && result>=70):
        document.write("Your restlt is : C");
        break;

    case(result<70 && result>=60):
         document.write("Your restlt is : D");
         break;


    case(result<60 && result>=0):
         document.write("Your restlt is : F");
         break;
         
    default:
    document.write("Invalid Number")
}