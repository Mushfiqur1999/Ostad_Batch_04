//(3) Topic: Multiplication Table Generator

var input = prompt("Enter Your Number : ")

for(var num=1;num<=10;num++){


document.write(num+" x "+input+" = "+num*input+"<br>");

}